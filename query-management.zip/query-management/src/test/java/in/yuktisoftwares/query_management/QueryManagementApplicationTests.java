package in.yuktisoftwares.query_management;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QueryManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
