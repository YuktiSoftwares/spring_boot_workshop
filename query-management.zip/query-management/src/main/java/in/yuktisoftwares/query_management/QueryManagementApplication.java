package in.yuktisoftwares.query_management;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QueryManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(QueryManagementApplication.class, args);
	}

}
